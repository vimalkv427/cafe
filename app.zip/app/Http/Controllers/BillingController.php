<?php

namespace App\Http\Controllers;

use App\Category;
use App\Subcategory;
use App\Product;
use App\Bill;
use App\Sale;
use App\Permission;

use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;

class BillingController extends Controller
{
    public function index()
    {
        $categories = Category::all(); // Fetch all categories
        return view('admin.billing.index', compact('categories'));
    }

    public function getProductByBarcode(Request $request)
    {
        $product = Product::where('barcode', $request->barcode)->first();

        if ($product) {
            return response()->json(['success' => true, 'product' => $product]);
        } else {
            return response()->json(['success' => false]);
        }
    }
    public function getProductsByBarcodes(Request $request)
    {
        $searchTerm = $request->input('search');

        if (!$searchTerm) {
            return response()->json(['success' => false, 'message' => 'Invalid search input']);
        }

        // Search by barcode or name (case-insensitive)
        $products = Product::where('barcode', $searchTerm)
            ->orWhere('name', 'LIKE', "%{$searchTerm}%")
            ->get();

        if ($products->isEmpty()) {
            return response()->json(['success' => false, 'message' => 'No products found']);
        }

        return response()->json(['success' => true, 'products' => $products]);
    }





    public function storeBill(Request $request)
    {
        DB::beginTransaction();

        try {
            // Create Bill
            $bill = Bill::create([
                'user_id' => auth()->id(),
                'customer_id' => $request->customer_id ?? null,
                'total_amount' => $request->total_amount,
                'paid_amount' => $request->paid_amount,
                'remaining_credit' => $request->remaining_credit,
            ]);

            // Create Sales
            foreach ($request->sales as $sale) {
                Sale::create([
                    'bill_id' => $bill->id,
                    'product_id' => $sale['product_id'],
                    'quantity' => $sale['quantity'],
                    'unit_price' => $sale['unit_price'],
                    'total_price' => $sale['total_price'],
                ]);
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Bill and Sales recorded successfully.']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }
}
