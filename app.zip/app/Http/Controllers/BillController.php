<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Bill; // Change to Sale model
use Illuminate\Support\Facades\Auth;

class BillController extends Controller
{
    public function index()
    {
        $bills = Bill::all(); // Fetch data from the sales table
        return view('admin.bills.index', compact('bills')); // Pass the sales data to the view
    }
    // public function show($id)
// {
//     $bill = Bill::with(['customer', 'sales.product'])->findOrFail($id);

//     return response()->json([
//         'bill' => $bill
//     ]);
// }
public function show($id)
{
    // Load the bill along with its related customer and sales (including product info)
    $bill = Bill::with(['customer', 'sales.product'])->findOrFail($id);
    return view('admin.bills.show', compact('bill'));
}

}
