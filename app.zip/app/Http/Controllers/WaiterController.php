<?php

namespace App\Http\Controllers;

use App\Category;
use App\Subcategory;
use App\Product;
use App\Bill;
use App\Sale;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class WaiterController extends Controller
{
    // Show products for the waiter to add to the temporary order
    public function index()
    {
        $categories = Category::all();
        return view('waiter.orders.index', compact('categories'));
    }

    // Store temporary order (before confirmation)
    public function storeTemporaryOrder(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        session()->push('temporary_order', [
            'product_id' => $request->product_id,
            'quantity' => $request->quantity,
            'unit_price' => $request->unit_price,
            'total_price' => $request->unit_price * $request->quantity,
        ]);

        return response()->json(['success' => true, 'message' => 'Item added to order.']);
    }

    // Confirm order and create bill
    public function confirmOrder(Request $request)
    {
        $orderItems = session('temporary_order', []);
        if (empty($orderItems)) {
            return response()->json(['success' => false, 'message' => 'No items in order.']);
        }

        DB::beginTransaction();
        try {
            // Create Bill
            $bill = Bill::create([
                'user_id' => auth()->id(),
                'customer_id' => $request->customer_id ?? null,
                'total_amount' => array_sum(array_column($orderItems, 'total_price')),
                'paid_amount' => 0,
                'remaining_credit' => 0,
            ]);

            // Add Sales
            foreach ($orderItems as $item) {
                Sale::create([
                    'bill_id' => $bill->id,
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'total_price' => $item['total_price'],
                ]);
            }

            DB::commit();
            session()->forget('temporary_order');
            return response()->json(['success' => true, 'message' => 'Order confirmed!']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    // Show order summary for waiter
    public function showOrderSummary()
    {
        $orderItems = session('temporary_order', []);
        return view('waiter.orders.summary', compact('orderItems'));
    }
}
