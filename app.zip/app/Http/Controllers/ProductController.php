<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Product;
use App\Category;
use App\Subcategory;

use Illuminate\Http\Request;

class ProductController extends Controller
{

    public function index()
    {
        // Get logged-in user ID
        $userId = auth()->id();

        // Fetch products that belong to the logged-in user
        $products = Product::with('category', 'subcategory')
            ->where('user_id', $userId)
            ->get();

        // Debugging (optional) - Check if products are being fetched
        if ($products->isEmpty()) {
            dd("No products found for user ID: " . $userId);
        }

        return view('admin.products.index', compact('products'));
    }



    public function add()
    {
        $userId = Auth::id(); // Get logged-in user ID
        $categories = Category::where('user_id', $userId)->get();
        $subcategories = SubCategory::where('user_id', $userId)->get();

        return view('admin.products.create', compact('categories', 'subcategories'));
    }

    public function store(Request $request)
    {
        // Validate input data
       

        // Handle image upload
        $imageName = null;
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '_' . $image->getClientOriginalName(); // ✅ Store original name with timestamp
            $image->move(public_path('uploads'), $imageName); // ✅ Move image to public/uploads
        }
        // Insert product into the database
        Product::create([
            'user_id' => auth()->id(),
            'name' => $request->name,
            'category_id' => $request->category_id,
            'sub_category_id' => $request->sub_category_id,
            'cost' => $request->product_cost,
            'product_selling_cost' => $request->product_selling_cost,
            'unit' => $request->unit,
            'quantity' => $request->product_quantity,
            'barcode'  => 123,
            'image' => $imageName,
            'description' => $request->product_details,
        ]);

        return redirect()->route('product.add')->with('success', 'Product added successfully!');
    }

    public function edit($id)
    {
        // Find the product by ID
        $product = Product::findOrFail($id);

        // Fetch categories and subcategories
        $categories = Category::all();
        $subcategories = SubCategory::where('category_id', $product->category_id)->get();

        // Return the edit view with product details
        return view('admin.products.create', compact('product', 'categories', 'subcategories'));
    }

    public function getSubcategories(Request $request)
    {
        $userId = Auth::id(); // Get the logged-in user's ID

        if (!$request->category_id) {
            return response()->json([]); // Return an empty array if category_id is missing
        }

        $subcategories = SubCategory::where('category_id', $request->category_id)
            ->where('user_id', $userId)
            ->get();

        return response()->json($subcategories);
    }

    public function update(Request $request, $id)
    {


        $product = Product::findOrFail($id);

        if ($request->hasFile('image')) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);
            $product->image = $imageName;
        }

        $product->update([
            'name' => $request->name,
            'barcode' => 123,
            'category_id' => $request->category_id,
            'sub_category_id' => $request->sub_category_id,
            'cost' => $request->product_cost,
            'product_selling_cost' => $request->product_selling_cost,
            'unit' => $request->unit,
            'quantity' => $request->product_quantity,
            'description' => $request->product_details,
        ]);

        return redirect()->route('product.index')->with('success', 'Product updated successfully!');
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        // Delete the image if it exists
        if ($product->image && file_exists(public_path('uploads/' . $product->image))) {
            unlink(public_path('uploads/' . $product->image));
        }

        $product->delete();

        return redirect()->route('product.index')->with('success', 'Product deleted successfully!');
    }
}
