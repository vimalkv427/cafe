@include('website.include.header')
@include('website.include.menubar')

<style>
    .foodmenu_tab_content {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 8px;
       
        margin-bottom: 15px;
        max-width: 100%;
        height: 100px; /* Fixed height for uniformity */
        overflow: hidden;
    }

    .menu_serial img {
        width: 80px; /* Set fixed width for images */
        height: 80px; /* Set fixed height for images */
        object-fit: cover; /* Ensure images are cropped properly */
        border-radius: 8px;
    }

    .menu_item {
        display: flex;
        flex-direction: column;
        justify-content: center;
        flex-grow: 1;
    }

    .menu_item_inner {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 5px;
    }

    .name {
        font-weight: bold;
        font-size: 16px;
    }

    .price {
        font-size: 14px;
        color: #e74c3c;
    }

    p {
        margin: 0;
        font-size: 12px;
        color: #555;
    }
</style>



<div class="page-header">
    <div class="page-header-content bg_image_header jarallax">
        <div class="container">
            <h1 class="heading">Our Menu</h1>
        </div>
    </div>
</div>

<div class="main-wrapper pt_0 pb_0">
    <div class="section_sm">
        <div class="container">
            <div class="section_header">
                <img src="{{ asset('web/images/title_back.png') }}" alt="">
                <h2 class="section_title">Restaurant Menu</h2>
                <h6 class="section_sub_title">Find your favourite meal from the delicious options we have</h6>
            </div>

            <!-- Category Tabs -->
            <div class="foodmenu_tab">
                
            
                <ul class="foodmenu_tab_button_group">
                    @foreach ($categories as $index => $category)
                        <li class="foodmenu_tab_button {{ $index === 0 ? 'active' : '' }}">
                            <a href="#tab-{{ $category->id }}">
                                <div class="tabicon">
                                    <img class="primary" src="{{ asset('web/images/tabicon_' . ($index + 1) . '_1.png') }}" alt="">
                                    <img class="secondary" src="{{ asset('web/images/tabicon_' . ($index + 1) . '_2.png') }}" alt="">
                                </div>
                                <span class="tab-text">{{ $category->category_name }}</span>
                            </a>
                        </li>
                    @endforeach
                </ul>

                <!-- Products -->
                <div class="foodmenu_tab_container">
                    @foreach ($categories as $index => $category)
                        <div class="foodmenu_tab_info {{ $index === 0 ? 'selected' : '' }}" id="tab-{{ $category->id }}">
                            <div class="row">
                                @php
                                    $categoryProducts = $products->where('category_id', $category->id);
                                @endphp

                                @forelse ($categoryProducts as $product)
                                    <div class="col-lg-6 col-md-6">
                                        <div class="foodmenu_tab_content">
                                            <div class="menu_serial">
                                                <img src="{{ asset('uploads/' . $product->image) }}" alt="">
                                            </div>
                                            <div class="menu_item">
                                                <div class="menu_item_inner">
                                                    <div class="name">{{ $product->name }}</div>
                                                    <div class="line"></div>
                                                    <div class="price">$ {{ $product->product_selling_cost }}</div>
                                                </div>
                                                <p>{{ $product->description }}</p>
                                            </div>
                                        </div>
                                    </div>
                                @empty
                                    <p>No products available in this category.</p>
                                @endforelse
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    <div class="grillman_imgtext light">
        <img src="{{ asset('web/images/grillman.png') }}" alt="" data-aos="fade-up" data-aos-duration="1000">
        <p>Hungrybuzz Restaurant</p>
    </div>

</div>

@include('website.include.footer')

<script>
    <script>
    document.querySelectorAll('.foodmenu_tab_button a').forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelectorAll('.foodmenu_tab_button').forEach(btn => btn.classList.remove('active'));
            button.parentElement.classList.add('active');
            document.querySelectorAll('.foodmenu_tab_info').forEach(tab => tab.classList.remove('selected'));
            const target = button.getAttribute('href').replace('#', '');
            document.getElementById(target).classList.add('selected');
        });
    });
</script>

</script>