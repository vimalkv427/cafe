<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bill Receipt - Bill #{{ $bill->id }}</title>
    <!-- Include your custom CSS for receipt styling -->
    <link rel="stylesheet" href="{{ asset('reciept/style.css') }}">
    <style>
        /* Optional: additional styles for header */
    </style>
</head>
<body>
    <div class="cs-container style1">
        <div class="cs-invoice cs-style1 padding_40">
            <div class="cs-invoice_in" id="download_section">
                <div class="cs-invoice_head cs-type1 column border-bottom-none">
                    <div class="display-flex justify-content-center cs-width_12">
                        <div class="cs-text_center">
                            <!-- Dynamic Supermarket Name from logged-in user -->
                            <p class="cs-f18 cs-primary_color cs-bold cs-mb2">
                                {{ auth()->user()->shop_name ?? 'Supermarket Name' }}
                            </p>
                            <!-- Optionally, you can also pull the address from the user if available -->
                            <p class="cs-m0 cs-primary_color cs-f14">
                                {{ auth()->user()->address_line ?? 'Address Line 1' }}
                            </p>
                            
                        </div>
                    </div>
                </div>
                <div class="cs-border cs-mb10"></div>
                <h5 class="cs-f16 cs-text_center text-transform-uppercase cs-mb10">Cash Receipt</h5>
                <div class="cs-border"></div>

                <div class="cs-table cs-style2 padding-rignt-left">
                    <table>
                        <thead>
                            <tr class="cs-f12">
                                <th class="cs-width_6 cs-normal cs-primary_color">Item</th>
                                <th class="cs-normal cs-primary_color">Price</th>
                                <th class="cs-normal cs-primary_color">Qty</th>
                                <th class="cs-normal cs-primary_color cs-text_right">Total</th>
                            </tr>
                        </thead>
                        <tbody class="cs-f12 tm-border-none">
                            @foreach($bill->sales as $sale)
                                <tr class="cs-primary_color">
                                    <td class="cs-p0 cs-p-b5">
                                        {{ $sale->product ? $sale->product->name : 'N/A' }}
                                    </td>
                                    <td class="cs-p0 cs-p-b5">₹{{ number_format($sale->unit_price, 2) }}</td>
                                    <td class="cs-p0 cs-p-b5">{{ $sale->quantity }}</td>
                                    <td class="cs-text_right cs-p0 cs-p-b5">₹{{ number_format($sale->total_price, 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="cs-border cs-mt12"></div>
                <div class="cs-table cs-style2 padding-rignt-left display-flex justify-content-flex-end">
                    <table class="cs-width_9">
                        <tbody class="cs-f12 tm-border-none">
                            <tr class="cs-primary_color">
                                <td>Total Quantity:</td>
                                <td class="cs-text_right">{{ $bill->sales->sum('quantity') }}</td>
                            </tr>
                            <tr class="cs-primary_color">
                                <td>Total Amount:</td>
                                <td class="cs-text_right">₹{{ number_format($bill->total_amount, 2) }}</td>
                            </tr>
                            <!-- Add additional rows as needed -->
                            <tr class="cs-primary_color">
                                <td>Grand Total:</td>
                                <td class="cs-text_right">₹{{ number_format($bill->total_amount, 2) }}</td>
                            </tr>
                            <tr class="cs-primary_color">
                                <td>Payment Mode:</td>
                                <td class="cs-text_right">{{ $bill->payment_mode ?? 'N/A' }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="cs-border cs-mb15 cs-mt12"></div>
                <div class="cs-text_center cs-mb10">
                    <img src="{{ asset('reciept/barcode.png') }}" alt="Barcode" />
                </div>
                <p class="cs-text_center cs-f16 cs-primary_color">Thank You</p>
            </div>
        </div>
    </div>
    
    <!-- Print and Back Buttons -->
    <div class="print-back-buttons" style="text-align:center; margin: 20px 0;">
        <button onclick="window.print();" class="btn btn-primary" style="margin-right:10px;">Print Bill</button>
        <button onclick="window.history.back();" class="btn btn-secondary">Back</button>
    </div>
</body>
</html>
